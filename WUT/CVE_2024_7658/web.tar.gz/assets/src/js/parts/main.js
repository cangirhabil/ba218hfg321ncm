(function () {
    'use strict';

    admin.parts.main = function () {

        $(document).ready(function() {
        });
    };
})();