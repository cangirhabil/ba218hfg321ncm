<?php
/**
 * This file prevents direct access to the upload folder.
 */
ps_redirect('../../index.php');
