<?php
// Text
$_['text_success']   = 'Success: Your currency has been changed!';

// Error
$_['error_currency'] = 'Warning: Currency could not be found!';